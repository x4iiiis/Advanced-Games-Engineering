# Astral Insanity
C++ 2D Shmup

| Windows Build | Linux / Mac Build |
| ------------- | ------------- |
| [![Windows Build status](https://ci.appveyor.com/api/projects/status/t88xlev0qxdpej83?svg=true)](https://ci.appveyor.com/project/dooglz/astral-insanity) | [![Unix Build status](https://travis-ci.org/dooglz/Astral_Insanity.svg?branch=master)](https://travis-ci.org/dooglz/Astral_Insanity) |


[![forthebadge](http://forthebadge.com/images/badges/designed-in-ms-paint.svg)](http://forthebadge.com)





